App.module('Client.Views', function(Views, App, Backbone, Marionette, $, _) {

    Views.NoItemView = Marionette.ItemView.extend({
        template: "template/no_item.tpl"   
    });
    
    Views.ClientItemView = Marionette.ItemView.extend({
        template: "template/client_item.tpl",
        tagName: "li",
        className: "topcoat-list__item",
        
        events: {
            'click #clientId': 'onClickClientId',
            'click #reload': 'onReloadClient'
        },
        
        onClickClientId: function() {
            this.trigger('client:click', this.model);
        },
        
        onReloadClient: function() {
            this.trigger('client:reload', this.model);
        }
	});
    
    Views.ClientCompositeView = Backbone.Marionette.CompositeView.extend({
        itemView: Views.ClientItemView,
    	itemViewContainer: "#clientList",
		template: "template/client_list.tpl",
        
        clientConnected: function(data){
            var self = this;
            socketServer.getClients(function(clients) {
                var clientList = _.map(clients, function(client){
                    var data = {
                        "clientId": client
                    }
                    return data;
                });
                self.collection.reset(clientList);
                self.render();
                self.onSetLocale();
            }, function(error) {
                console.log(error);
            });
        },
        
        clientDisconnected: function(data){
            var self = this;
            socketServer.getClients(function(clients) {
                var clientList = _.map(clients, function(client){
                    var data = {
                        "clientId": client
                    }
                    return data;
                });
                self.collection.reset(clientList);
                self.render();
                self.onSetLocale();
            }, function(error) {
                console.log(error);
            });
        },
    
        emptyView: Views.NoItemView,
        
        events: {
    		'click #locale': 'onSetLocale'
		},
        
        setLocale: function() {
            navigator.globalization.getLocaleName(
                function (locale) {
                    if(locale.value == 'ja_JP') {
                        $("[data-localize]").localize("client", { language: "ja", pathPrefix: "lang" });                        
                    }
                    if(locale.value == 'zh_CN') {
                        $("[data-localize]").localize("client", { language: "cn", pathPrefix: "lang" });                        
                    }
                },
                function () {console.log('Error getting locale\n');}
            );
        },
        
        onSetLocale: function() {
            this.setLocale();
        },
        
        onShow: function(){
            this.setLocale();
            this.listenTo(App, "client:connected", this.clientConnected); 
            this.listenTo(App, "client:disconnected", this.clientDisconnected);
        }
        
    });

});