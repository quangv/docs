function startWebSocketServer(){
  cordova.exec(
        function(response) {            
            if(response.event === 'server:started'){
                App.trigger('websocketserver:started', response);
            }
            
            if(response.event === "open"){
                // client is connected
                var clientId = response.client;
                console.log('client ' + clientId + " connected");
                App.trigger('client:connected', clientId);
            }
            
            if(response.event === "close"){
                // client is disconnected
                var clientId = response.client;
                console.log('client ' + clientId + " disconnected");
                App.trigger('client:disconnected', clientId);
            }
            
            if(response.event === 'message'){
                var message = JSON.parse(response.message);
                if(message.tvdetail){
                    App.trigger('get:tvdetail', message.tvdetail);
                }
            }
    		console.log(JSON.stringify(response));
		}, 
		function(error) {
			alert('error ' + error );
		}, 
		"WebSocket",
     "start", [{port: 3001}]);
}

function getAddress(){
    cordova.exec(
        function(message) {
          	console.log(JSON.stringify(message));
  		},
  		function(error) {
  			alert('error ' + error );
  		},
  		"WebSocket",
       "getAddress", []);
}
  
function getClients(){
    var defer = $.Deferred();
    cordova.exec(
    	function(clients) {
			console.log(JSON.stringify(clients));
            defer.resolve(clients);
		}, 
		function(error) {
			alert('error ' + error );
		},
		"WebSocket",
     "getClients", []);
     
     return defer.promise();
}

function sendMessage(client, message){
    var options = {
        "clientId": client,
        "message": message
    }
    cordova.exec(
        function(message) {
			console.log(JSON.stringify(message));
		}, 
		function(error) {
			alert('error ' + error );
		}, 
		"WebSocket",
        "send", [options]);
}

function stopWebSocketServer(){
	cordova.exec(
		function(message) {
			console.log(message);
		}, 
		function(error) {
			console.error('error ' + error );
		}, 
		"WebSocket",
     "stop", []);
}