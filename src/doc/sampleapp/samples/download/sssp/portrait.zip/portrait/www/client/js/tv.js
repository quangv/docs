var ua = navigator.userAgent.toLowerCase();
var isSmartTV = ua.indexOf("smarttv") > -1;
if(isSmartTV) {
    var widgetAPI = new Common.API.Widget(); // Create Common module
    var pluginAPI = new Common.API.Plugin();
    var tvKey = new Common.API.TVKeyValue();
    
    var clientUrl = '/mtd_down/common/HospitalityBrowser/';
    var xhrCurrent = null;
    var URL, serverDir;
    var source = serverDir + 'data/config.json';
    var destination = clientUrl + 'data/config.json';
}

App.module('TV', function(TV, App, Backbone, Marionette, $, _) {
    
    TV.Remote = {
        
        fetchServer: function(source, destination) {
            DownloadPlugin.OnComplete = this.fnDnStatus;
            console.log('source: ' + source + ' destination: ' + destination);
            DownloadPlugin.StartDownFile(source, destination, 10000, 10);
        },
        
        fnDnStatus: function(msg) {
            console.log('fnCallback' + msg );
            var tArrResult = msg.split("?");
            for (var i=0 ; i<tArrResult.length ; i++) {
                console.log("tArrResult[" + i + "] = " + tArrResult[i]);
            }
            // DownResult : If res=1 success, otherwise ERROR (see end of this file)
            if (tArrResult[0]==1000 ) {
                console.log('DownResult: ' + tArrResult[1]);
                if(tArrResult[1] == 1) console.log('Download successful');
                else console.log('Download error');
            }
            // DownRatio : 0~100
            else if (tArrResult[0]==1001 ) {
                console.log('DownlaodedRation: ' + tArrResult[1]);
            }
            // Down Speed : Bytes/Sec : It will be reach after Ratio
            else if (tArrResult[0]==1002 ) {
                console.log('DownSpeed: ' + tArrResult[1] + ' Bytes/Sec');
            }
        },
        
        getServerDir: function() {
            if(isSmartTV) {
                var fs = new FileSystem();
                URL = fs.getHotelServerURL();
                var lastSlash = URL.lastIndexOf("/");
                serverDir = URL.substring(lastSlash,0) + '/';
                return serverDir;
            }
        },

        runVolumeDown: function() {
            AudioPlugin.SetVolumeWithKey(1);
            console.log('Volume: ' + AudioPlugin.GetVolume());
            document.getElementById("volumebox").style.display = "block";
            document.getElementById("volume").innerHTML = AudioPlugin.GetVolume();
            setTimeout(function() {
                document.getElementById("volumebox").style.display = "none";
                document.getElementById("volume").innerHTML = "";
            }, 2000);
        },
        
        runVolumeUp: function() {
            AudioPlugin.SetVolumeWithKey(-1);
            console.log('Volume: ' + AudioPlugin.GetVolume());
            document.getElementById("volumebox").style.display = "block";
            document.getElementById("volume").innerHTML = AudioPlugin.GetVolume();
            setTimeout(function() {
                document.getElementById("volumebox").style.display = "none";
                document.getElementById("volume").innerHTML = "";
            }, 2000);
        },
        
        playVideo: function() {
            var video = document.getElementById("video");
            if (video.paused) {
                video.play();
            } else {
                video.pause();
            }
        },
        
        stopVideo: function() {
            var video = document.getElementById("video");
            video.stop();
        },
        
        pauseVideo: function() {
            var video = document.getElementById("video");
            video.pause();
        },
        
        getVolume: function() {
            return AudioPlugin.GetVolume();
        },
        
        getTvDetail: function() {
            var MAC, DUID, CON, FIRMWARE, VOLUME;
            var cType = NetworkPlugin.GetActiveType();
            if(cType == 1) {
                MAC = NetworkPlugin.GetMAC();
                DUID = NNaviPlugin.GetDUID(MAC);
                CON = "LAN";
            }
            if(cType == 0) {
                MAC = NetworkPlugin.GetMAC(0);
                DUID = NNaviPlugin.GetDUID(MAC);
                CON = "WIRELESS";
            }
            if(cType == -1) {
                CON = "NOT CONNECTED";
            }
            FIRMWARE = NNaviPlugin.GetFirmware();
            VOLUME = AudioPlugin.GetVolume();
            var data = {
                "mac": MAC,
                "duid": DUID,
                "con": CON,
                "firmware": FIRMWARE,
                "volume": VOLUME,
                "model": DevicePlugin.GetRealModel(),
                "system_version_leeum": NNaviPlugin.GetSystemVersion(1),
                "system_version_comp": NNaviPlugin.GetSystemVersion(0),
                "widget_manager_path": NNaviPlugin.GetPath(0),
                "widget_normal_path": NNaviPlugin.GetPath(1),
                "appkey": NNaviPlugin.GetAppKey(),
                "widget_id": curWidget.id,
                "usb_count": StoragePlugin.GetUSBListSize(),
                "directory_size": FileSystemPlugin.GetFolderSize(clientUrl, 1, 0),
                "hdd_size": FileSystemPlugin.GetTotalSize()
            }
            return data;
        },
        
        onKeyDown: function() {
            var self = this;
            var keyCode = event.keyCode;
            console.log('keydown on keycode ' + keyCode);
        
            switch(keyCode) {
                case tvKey.KEY_1:
                    console.log('key_1');
                    break;
                case tvKey.KEY_LEFT:
                	console.log('key_left');
            		break;
            	case tvKey.KEY_RIGHT:
            		console.log('key_right');
            		break;
            	case tvKey.KEY_UP:
            		console.log('key_up');
            		break;
            	case tvKey.KEY_DOWN:
            		console.log('key_down');
            		break;
            	case tvKey.KEY_ENTER:
            		console.log('key_enter');
                    window.location.reload();
                	break;
            	case tvKey.KEY_RETURN:
            		console.log('key_return');
                    widgetAPI.blockNavigation(event);
                    break;
                case tvKey.KEY_PLAY:
                    console.log('key_play');
                    self.playVideo();
                    break;
                case tvKey.KEY_STOP:
                    console.log('key_stop');
                    self.stopVideo();
                    break;
                case tvKey.KEY_PAUSE:
                    console.log('key_pause');
                    self.pauseVideo();
                    break;
                case tvKey.KEY_VOL_UP:
                    self.runVolumeUp();
                    break;
                case tvKey.KEY_VOL_DOWN:
                    self.runVolumeDown();
                    break;
            }
        }
    }
    
});



function getURL() {
	var fs = new FileSystem();
	URL = fs.getHotelServerURL();
	//console.log("getHotelServerURL() returns : " + URL);
	return URL;
}

function getServerDir() {
    var fs = new FileSystem();
    URL = fs.getHotelServerURL();
    var lastSlash = URL.lastIndexOf("/");
    serverDir = URL.substring(lastSlash,0) + '/';
    return serverDir;
}

function checkReadyState(obj) {	
	console.log("checkReadyState :: obj.readyState: "+obj.readyState)
    if( obj.readyState == 3 ) {
	}
	else if( obj.readyState == 4 ){
		console.log("checkReadyState :: obj.status: "+obj.status)
		if( obj.status == 200 ) {
			return true;
		}
		else {
			console.log("Problem retrieving XML data: status: "+obj.status);
			var fs;
			fs = new FileSystem();
			var fp = fs.openCommonFile(clientUrl + "index.html", "r");
			if( fp ) {
				/*var offlineHtml = fp.readAll();
				document.body.innerHTML = offlineHtml;*/
				fs.closeFile(fp);
				location.href = clientUrl + "index.html";
			}
			else {
				console.log('Error retrieving file.');
                obj.abort();
			}
		}
	}
	else {
	}
	return false;
}

function createXHR(xhr) {
	if( xhr == null ) {
		xhr = new XMLHttpRequest();
	}
	else {
		//reuse XHR		
	}
	if( xhr == null ) {
		console.log("ERROR: XHR creation failed");
	}
	return xhr;
}

function XHRTest(url) {
	console.log("XHRTest( "+ url +" )")
	xhrCurrent = createXHR(xhrCurrent);
	if (xhrCurrent) {
		xhrCurrent.onreadystatechange = onLoadTest;
		xhrCurrent.open("GET", url, true);
		xhrCurrent.send(null);
	}
}

function onLoadTest() {
    console.log("onLoadTest()")
	if( checkReadyState(xhrCurrent) ) {
		console.log("checkReadyState return true : redirect to " + URL)
		location.href = URL;
	}
}	

fetchServer = function(source, destination) {
    //var divElement = document.getElementById("title");
    //widgetAPI.putInnerHTML(divElement, "Downloading...");
    DownloadPlugin.OnComplete = fnDnStatus;
    console.log('source: ' + source + ' destination: ' + destination);
    DownloadPlugin.StartDownFile(source, destination, 10000, 10);
    //DownloadPlugin.StartDownFile(source, '??', 10000, 10);
}

getListFiles = function(dir) {
    return SefPlugin.Execute("GetListFiles", dir);
}

function fnDnStatus(msg) {
    console.log('fnCallback' + msg );
    var tArrResult = msg.split("?");
    for (var i=0 ; i<tArrResult.length ; i++) {
        console.log("tArrResult[" + i + "] = " + tArrResult[i]);
    }
    // DownResult : If res=1 success, otherwise ERROR (see end of this file)
    if (tArrResult[0]==1000 ) {
        console.log('DownResult: ' + tArrResult[1]);
        if(tArrResult[1] == 1) console.log('Download successful');
        else console.log('Download error');
    }
    // DownRatio : 0~100
    else if (tArrResult[0]==1001 ) {
        console.log('DownlaodedRation: ' + tArrResult[1]);
    }
    // Down Speed : Bytes/Sec : It will be reach after Ratio
    else if (tArrResult[0]==1002 ) {
        console.log('DownSpeed: ' + tArrResult[1] + ' Bytes/Sec');
    }
}