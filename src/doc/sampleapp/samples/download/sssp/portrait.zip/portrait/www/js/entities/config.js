App.module('Entities', function(Entities, App, Backbone, Marionette, $, _) {
    
	Entities.Config = Backbone.Model.extend({});

	var configs;
    
    var initialize = function() {
		var defer = $.Deferred();
        
        var url = serverRootDir + "data/config.json";
        
        getData(url).done(function(data){
            //alert('configData: ' + JSON.stringify(data));
			configs = new Backbone.Model(data);
			defer.resolve(configs);
		});

		return defer.promise();
	};

	var getData = function(url) {
		console.log('url: ' + url);
		var defer = $.Deferred();
		$.ajax({
			url: url,
			'dataType': 'json',
			success: function(data) {
				//console.log('got data from server. ' + JSON.stringify(data));
				defer.resolve(data);
			},
			error: function(data){
				console.log('error ' + JSON.stringify(data));
				defer.resolve(undefined);
			}
		});
		return defer.promise();
	};

	var API = {
		getConfigEntity: function() {
			return initialize();
		}
	};

	App.reqres.setHandler('config:entities', function() {
        return API.getConfigEntity();
	});
});