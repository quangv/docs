App.module('Config.List.Views', function(Views, App, Backbone, Marionette, $, _) {

	Views.ConfigItemView = Marionette.ItemView.extend({
		template: "template/config_item.tpl",
        
        events: {
            'click #settingBtn': 'onClickSettingBtn',
            'change #slide_time': 'onChangeSlideTime'
	    },
        
        onChangeSlideTime: function(e) {
            this.$("#slide_time_label").html(e.target.value);
            this.model.set("slide_time", e.target.value);
            var data = {
                "slide_time": e.target.value
            }
            iScroll.destroy();
            this.trigger('slidetime:changed', data);
        },

	    onClickSettingBtn: function(){
	        this.trigger('settingbtn:click', this.model);
	    },
        
        setLocale: function() {
            navigator.globalization.getLocaleName(
                function (locale) {
                    if(locale.value == 'ja_JP') {
                        $("[data-localize]").localize("setting", { language: "ja", pathPrefix: "lang" });                        
                    }
                    if(locale.value == 'zh_CN') {
                        $("[data-localize]").localize("setting", { language: "cn", pathPrefix: "lang" });                        
                    }
                },
                function () {console.log('Error getting locale\n');}
            );
        },
        
        onShow: function(){
            this.setLocale();
	    }
	});
    
    Views.Preview = Marionette.ItemView.extend({
        template: "template/preview.tpl",
        
        initialize: function() {
            var self = this;
            Handlebars.registerHelper("getUrl", function(value) {
                return "http://" + serverUrl.ip + ":" + serverUrl.port;
            });
        }
    });

});