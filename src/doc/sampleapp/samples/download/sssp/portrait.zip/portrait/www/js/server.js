//System.out:   HDR: 'user-agent' = 'Mozilla/5.0 (SmartHub; SMART-TV; U; Linux/SmartTV; Maple2012) AppleWebKit/534.7 (KHTML, like Gecko) SmartTV Safari/534.7'

function startServer(){
    cordova.exec(
        function(message) {                
			console.log(JSON.stringify(message));
            serverUrl = message;
            getServerRootDir();
            //alert(serverUrl+" root directory: "+serverRootDir);
    	}, 
		function(error) {
			alert('error ' + error );
		}, 
		"HttpServer",
     "start", ["www/client/", {port: 3000}]);
}

function stopServer(){
	cordova.exec(
		function(message) {
			console.log(message);
    	}, 
		function(error) {
			alert('error ' + error );
		}, 
		"HttpServer",
     "stop", []);
}

function getServerRootDir(){
    var defer = $.Deferred();
    cordova.exec(
		function(message) {
    		console.log('get server rootDir success:' + message);
            serverRootDir = message;
            App.trigger('server:initialized');
            window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFS, fail);
		}, 
		function(error) {
			alert('error ' + error );
        }, 
		"HttpServer",
     "getServerRoot", []);
}

function gotFS(fileSystem) {
    fileSystem.root.getFile( serverRootDir + "/readme.txt", {create: true, exclusive: false}, gotFileEntry, fail);
}

function gotFileEntry(fileEntry) {
    fileEntry.createWriter(gotFileWriter, fail);
}

function gotFileWriter(writer) {
    // writer.onwriteend = function(evt) {
    //     console.log("contents of file now 'some sample text'");
    //     writer.truncate(11);  
    //     writer.onwriteend = function(evt) {
    //         console.log("contents of file now 'some sample'");
    //         writer.seek(4);
    //         writer.write(" different text");
    //         writer.onwriteend = function(evt){
    //             console.log("contents of file now 'some different text'");
    //         }
    //     };
    // };
    writer.write("some sample text");
}

function fail(error) {
    console.log(error.code);
}

function fail(evt) {
    console.log(evt.target.error.code);
}