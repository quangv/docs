App.module('ScreenLayout.Views', function(Views, App, Backbone, Marionette, $, _) {
	Views.ScreenLayout = Marionette.Layout.extend({
		template: 'js/framework/screen_layout/screen_layout.tmpl',		

		regions: {
			contentRegion: {
				selector: '#screen-layout',
				regionType: App.ScreenLayout.Views.SlidingLayoutRegion
			}
		}
	});

});