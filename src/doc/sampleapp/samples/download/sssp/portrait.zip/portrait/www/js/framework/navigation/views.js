App.module('Navigation.Views', function(Views, App, Backbone, Marionette, $, _) {
	Views.NavigationController = Marionette.Layout.extend({
		template: 'js/framework/navigation/navigation_layout.tmpl',
		viewStack: [],

		events: {
			'click #left-button': 'leftNavigationItemClicked',
			'click #right-button': 'rightNavigationItemClicked',
			'click #content-region': 'contentRegionClicked'
		},

		regions: {
			contentRegion: {
				selector: '#content-region',
				regionType: App.Navigation.Regions.ContentRegion
			}
		},

		initialize: function(options) {
			if (options.rootView) {
				this.rootView = options.rootView;
			} else {
				console.warn("[NavigationController] rootView is not provided");
			}

			if (options.leftButtonIcon) {
				this.leftButtonIcon = option.leftButtonIcon;
			}

			this.contentRegion.on('show', this.onChildViewShow, this);
		},

		leftNavigationItemClicked: function(e) {			
			if (this.canShowPreviousView()) {
				this.showPreviousView();
			} else {
				this.trigger('left-navigation-item:clicked');
			}
		},

		rightNavigationItemClicked: function(e) {
			this.trigger('right-navigation-item:clicked');
		},

		contentRegionClicked: function() {
			this.trigger('content:clicked');
		},

		canShowPreviousView: function() {
			return this.viewStack.length > 1;
		},

		showChildView: function(view, animation) {
			if (view.navigationBarItem) {
                if(view.navigationBarItem.title) {
    			    this.setNavigationBarTitle(view.navigationBarItem.title, animation);
                }
                if(view.navigationBarItem.leftButtonIcon) {
                    this.setLeftButtonIcon(view.navigationBarItem.leftButtonIcon);
                }
                if(view.navigationBarItem.rightButtonIcon) {
                    this.setRightButtonIcon(view.navigationBarItem.rightButtonIcon);
                }
			}
			this.contentRegion.show(view, animation);

			this.viewStack.push(view);
			this.updateLeftButtonIcon();
		},

		setLeftButtonIcon: function(leftButtonIcon) {			
			this.leftButtonIcon = leftButtonIcon;
			this.updateLeftButtonIcon();
		},

		setRightButtonIcon: function(rightButtonIcon) {
			this.rightButtonIcon = rightButtonIcon;
			this.$('#right-button-icon').attr("class", "topcoat-icon topcoat-icon--" + this.rightButtonIcon);
		},

		updateLeftButtonIcon: function() {
			if (this.viewStack.length < 2) {
				this.resetLeftButtonIcon();
			} else {
				this.changeLeftButtonIconToBack();
			}
		},

		resetLeftButtonIcon: function() {
			this.$('#left-button-icon').attr("class", "topcoat-icon topcoat-icon--" + this.leftButtonIcon);
		},

		changeLeftButtonIconToBack: function() {
			this.$('#left-button-icon').attr("class", "topcoat-icon topcoat-icon--back");
		},

		setNavigationBarTitle: function(title, from) {
			var to = "";
			if (from) {
				to = from === "left" ? "right" : "left";
			}

			var previousTitle = this.$('#center span');

			var nextTitle = $('<span>' + title + '</span>');
            nextTitle.attr('data-localize', 'title');
			nextTitle.attr('class', 'topcoat-navigation-bar__title animation ' + from);
			this.$('#center').append(nextTitle);

			if (!from) { // no animation
				previousTitle.remove();
				return;
			} else {
				previousTitle.one('webkitTransitionEnd', function(e) {
					previousTitle.remove();
				});
			}

			// Force reflow. More information here: http://www.phpied.com/rendering-repaint-reflowrelayout-restyle/
			this.$el[0].offsetWidth;

			previousTitle.attr("class", "topcoat-navigation-bar__title animation transition " + to);
			nextTitle.attr("class", "topcoat-navigation-bar__title animation transition center");
		},

		resetRootView: function(view, animation) {
			this.viewStack = [];
			this.showChildView(view, animation);
		},

		showPreviousView: function() {
			if (this.viewStack.length < 2) {
				// only one view is in the stack -> no previous view
				console.warn("[NavagationController] no previous view to show");
				return;
			}

			this.viewStack.pop();
			var previousView = this.viewStack.pop();
			this.showChildView(previousView, "left");
			previousView.delegateEvents();
		},

		onShow: function(view) {
			if (this.rootView) {
				this.showChildView(this.rootView);
			}
			this.fixContentRegionTop();
		},


		fixContentRegionTop: function(){
			var toolbarHeight = this.$('#navigation').css('height') + 1;
			this.$('#content-region').css('top', toolbarHeight);
		},

		onChildViewShow: function(view) {
			console.log('[NavigationController] onChildViewShow');
		}
	});

	Views.ToolbarView = Marionette.ItemView.extend({

	});
});