App.module('Photo.List.Views', function(Views, App, Backbone, Marionette, $, _) {

    Views.NoItemView = Marionette.ItemView.extend({
        template: "template/no_item.tpl",
        tagName: "div",
        className: "full"
    });
    
    Views.PhotoItemView = Marionette.ItemView.extend({
	    template: "template/photo_item.tpl",
        emptyView: Views.NoItemView,
        defaultClassName: "full",
        className: function() {
            if(this.model && (this.model.get('orientation') == 6)) {
                return this.defaultClassName + ' rotate90';
            } else if(this.model && (this.model.get('orientation') == 8)) {
                return this.defaultClassName + ' rotate270';
            }
            else {
                return this.defaultClassName;
            }
        }
	});

});