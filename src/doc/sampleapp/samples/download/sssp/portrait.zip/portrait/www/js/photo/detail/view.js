App.module('Photo.Detail.Views', function(Views, App, Backbone, Marionette, $, _) {

	Views.PhotoDetailView = Marionette.ItemView.extend({
	    template: "template/photo_detail.tpl",
        
        initialize: function() {
            var self = this;
            Handlebars.registerHelper("getFileUrl", function(value) {
                var fileName = self.model.get("filename");
                return serverRootDir + "data/photo/" + fileName;
            });
            Handlebars.registerHelper("getRotate", function(value) {
                var orientation = self.model.get("orientation");
                if(orientation == 6) return "width: 312px !important; margin-left: -68px; -webkit-transform: rotate(90deg);";
                if(orientation == 8) return "width: 312px !important; margin-left: -68px; -webkit-transform: rotate(-90deg);";
            });
            Handlebars.registerHelper("toggleClass", function(value) {
                var enable = self.model.get("enable");
                if(enable == 1) return "active";
            });
        },
	    
	    events: {
	        'click #updateBtn': 'updateBtn',
	        'click #deleteBtn': 'deleteBtn',
            'click #enableToggle': 'toggleEnabled'
	    },
        
        toggleEnabled: function() {
            this.model.set("enable", !this.model.get("enable"));
            this.render();
            this.setLocale();
        },
        
        setLocale: function() {
            navigator.globalization.getLocaleName(
                function (locale) {
                    if(locale.value == 'ja_JP') {
                        $("[data-localize]").localize("photo-detail", { language: "ja", pathPrefix: "lang" });                        
                    }if(locale.value == 'zh_CN') {
                        $("[data-localize]").localize("photo-detail", { language: "cn", pathPrefix: "lang" });                        
                    }
                },
                function () {console.log('Error getting locale\n');}
            );
        },
        
        onShow: function(){
            this.setLocale();
        },

	    updateBtn: function(){
	        console.log('onClick updateBtn');
	        var id = this.$('#id').val();
            var title = this.$('#title').val();
            var enable = 0;
            if(this.model.get("enable"))    enable = 1;
            var data = {
                id: id,
                title: title,
                enable: enable
            }
            this.trigger('update-btn:clicked', data);
	    },

	    deleteBtn: function(){
	    	console.log('onClick deleteBtn');
	    	var id = this.$('#id').val();
            var fileName = this.$('#filename').val();
            var data = {
                id: id,
                fileName: fileName
            }
            this.trigger('delete-btn:clicked', data);
	    }
	});

});