App.module('ScreenLayout.Views', function(Views, App, Backbone, Marionette, $, _) {

	Views.SlidingLayoutRegion = Marionette.Region.extend({		
		viewStack: [],

		initialize: function(options) {
			this.el = options.el;
		},

		show: function(view, from) {
			view.animation = from;

			this.ensureEl();

			var isViewClosed = view.isClosed || _.isUndefined(view.$el);

			var isDifferentView = view !== this.currentView;

			view.render();

			if (isDifferentView || isViewClosed) {
				this.open(view, from);
			}

			this.currentView = view;
			this.viewStack.push(view);

			Marionette.triggerMethod.call(this, "show", view);
			Marionette.triggerMethod.call(view, "show");
		},

		canShowPreviousView: function() {
			return this.viewStack.length > 1;
		},

		showPreviousView: function() {
			if (this.viewStack.length < 2) {
				// only one view is in the stack -> no previous view				
				return;
			}

			this.currentView = this.viewStack.pop();
			var currentViewAnimation = this.currentView.animation;

			if (currentViewAnimation === "modal") {
				this.closeModal();
			} else {
				var previousView = this.viewStack.pop();
				var oppositeAnimation = this.getOppositeAnimation(currentViewAnimation);
				this.show(previousView, oppositeAnimation);
				previousView.delegateEvents();
			}
		},

		open: function(view, animation) {
			if (animation === 'modal') {
				this.openModal(view, animation);
			} else {
				this.animateFrom(view, animation);
			}
		},

		animateFrom: function(view, from) {
			var to = this.getOppositeAnimation(from);

			var that = this;
			var previousView = this.currentView;

			// add page to container
			var pager = $('<div></div>');
			pager.append(view.el);
			this.$el.append(pager);

			// start position
			pager.attr("class", "screen " + from);

			if (!previousView || previousView.isClosed) {
				pager.attr("class", "screen center");
				return;
			}

			var previousPager = previousView.$el.parent();
			pager.one('webkitTransitionEnd', function(e) {
				that.closeView(previousView);
				previousPager.remove();

			});

			// Force reflow. More information here: http://www.phpied.com/rendering-repaint-reflowrelayout-restyle/
			this.$el[0].offsetWidth;

			// animate the from start to center
			// and center page to the left
			pager.attr("class", "screen transition center");
			previousPager.attr("class", "screen transition " + to);
		},

		openModal: function(view, animation) {
			var that = this;

			var modalBehindPage = this.$el.find('.screen');

			// add page to container
			var pager = $('<div id="modal"></div>');
			pager.append(view.el);
			this.$el.append(pager);

			// start position
			pager.attr("class", "screen unmodal");

			// Force reflow. More information here: http://www.phpied.com/rendering-repaint-reflowrelayout-restyle/
			this.$el[0].offsetWidth;

			// animate the from start to center
			// and center page to the left
			modalBehindPage.attr('class', "screen transition modal-behind");
			pager.attr("class", "screen transition center");			
		},

		closeModal: function() {
			var that = this;

			var pager = this.$el.find('#modal');

			var modalBehindPage = this.$el.find('.modal-behind');
			pager.one('webkitTransitionEnd', function(e) {
				that.closeView(that.currentView);
				pager.remove();
			});

			// Force reflow. More information here: http://www.phpied.com/rendering-repaint-reflowrelayout-restyle/
			this.$el[0].offsetWidth;

			// animate the from start to center
			// and center page to the left
			modalBehindPage.attr('class', 'screen transition');
			pager.attr("class", "screen transition unmodal");
		},

		getOppositeAnimation: function(animation) {
			var opposite;
			if (animation === 'left' || animation === 'right') {
				opposite = animation === "left" ? "right" : "left";
			} else if (animation === 'up' || animation === 'down') {
				opposite = animation === 'up' ? "down" : "up";
			} else if (animation === 'modal' || animation === 'unmodal') {
				opposite = animation === 'modal' ? "unmodal" : "modal";
			}
			return opposite;
		},

		close: function() {
			// var view = this.currentView;
			// if (!view || view.isClosed){ return; }

			// call 'close' or 'remove', depending on which is found
			// if (view.close) { view.close(); }
			// else if (view.remove) { view.remove(); }

			// Marionette.triggerMethod.call(this, "close");

			// delete this.currentView;
		},

		closeView: function(view) {
			console.log("[ContentRegion] closeView()");
			if (view.close) {
				view.close();
			} else if (view.remove) {
				view.remove();
			}

			Marionette.triggerMethod.call(this, "close");
		},

		onClose: function(view) {
			console.log('[ContentRegion] onClose(view)');
		}
	});

});