App.module('About.Help.Views', function(Views, App, Backbone, Marionette, $, _) {

    Views.HelpItemView = Marionette.ItemView.extend({
        template: "template/help.tpl",
        
        onShow: function(){
            navigator.globalization.getLocaleName(
                function (locale) {
                    if(locale.value == 'ja_JP') {
                        $("[data-localize]").localize("help", { language: "ja", pathPrefix: "lang" });                        
                    }
                },
                function () {console.log('Error getting locale\n');}
            );
        }
	});

});