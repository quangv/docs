(日本語の説明は英語の後に記述されます)

Tenponochikara Portrait
==================

This project contains the demo application of Tenponochikara Portrait made for Samsung Smart TV.
Digital Signage is widely used to serve the advertisement display on the TV screen. By
using this application, you can easily update the content and choose what to display
on the screen real-time right away from your android device.
Your TODO
---------

1. HTTP Server and Websocket Server Port

  The HTTP Server and Websocket Server Port are specified in index.html.
  You can change the port according to your preference.

2. Change look & feel

  This application is divided into two categories:
  
  - Server side: Application running on Android Device
  - Client side: Webpage to be shown on TV screen
  
  Server side page contains entire HTML except client directory. The index.html contains
  entire HTML as well as main program of the page. All the framework and css files are included here.
  On the other hand, index.ui which is the Native component of the page set the screenOrientation to portrait.
  index.ui describes native UI component of the page. You can see the reference
  by the url: <http://docs.monaca.mobi/reference/native_ui/>

  Server side page also contains the language files which can be found in lang directory. The file is in the format
  of xxx-ja.json & xxx-cn.json. The default language of the appplication is English while the language will be switched
  automatically according to the device's language.
  
  The template files are stored in template directory. If you wish to change content of the application,
  you can do that by editing the files inside this directory.
  
  This application uses Topcoat UI design which is a brand new open source CSS library to build web apps.
  More information can be located here <http://topcoat.io/>
  
  Server side page has been comprised with the following plugins and frameworks:
  
  ◎ Monaca HTTP Server
  
  ◎ Monaca WebSocket Server
  
  ◎ Cordova Plugin: Cordova is an open-source mobile development framework which allows you to use standard
  web technologies such as HTML5, CSS3, and JavaScript for cross-platform development. You can see the reference at
  <http://phonegap.com/>
  
  ◎ Backbone: a javascript framework which gives structure to the web applications by providing models with key-value binding and custom events and collections.
  You can see the reference at <http://backbonejs.org/>
  
  ◎ Marionette: Marionette is a composite application library for Backbone.js that aims to simplify the construction of large scale JavaScript applications.
  More information can be found at <http://marionette.js/>
  
  ◎ Underscore:  is a utility-belt library for JavaScript that provides a lot of the functional programming support
  which go along with Backbonejs. Please refer to this link <http://http://underscorejs.org/>
  
  ◎ iScroll: provides Pinch / Zoom, Pull up/down to refresh, Customizable scrollbars to android device. <http://cubiq.org/iscroll-4/>
  
  ◎ Fastclick: FastClick is a simple, easy-to-use library for eliminating the 300ms delay between a physical tap and the firing of a click event on mobile browsers.
  You can find it at <https://github.com/ftlabs/fastclick/>
  
  ◎ Modernizr: the Javascript library that detects the HTML5 and CSS3 features. <http://modernizr.com//>
  
  ◎ Pageslider: A simple library providing hardware accelerated page transitions for Mobile Apps. <https://github.com/ccoenraets/PageSlider/>
  
  ◎ jQuery Localization: A jQueyr library to give a translation of your web applications. <https://github.com/coderifous/jquery-localize/>
  
  ◎ TAFFY: An opensouce library that brings database features into your JavaScript applications. <http://taffydb.com/>
  
  You can add or remove plugins through Config toolbar -> Plugin Settings. The minimum plugins required for this
  application are: jQuery, Monaca Server, monaca.js, monaca.viewport.js, Adobe PhoneGap (Cordova). These plugins are
  being loaded in the plugin-loader.js
  
  Client side page contains json database of this application and the data will be stored in client/data directory.
  If you wish to change the application content, you can modify css file in css directory, and the template files in 
  template directory.

3. Change behavior

  The main JavaScript program is loaded from js/controller.js.
  You can modify source code to suite your needs.
 
4. Debug

  You need to use Monaca Debugger to check the behaviour. It is not possible to 
  check it on-line, because this application contains some functions which require Android device to run on.
 
5. Build & Deploy

  You can build & deploy this app for Google Play. Please 
  refer to the manual for details: <http://docs.monaca.mobi/manual/build_index/>


店舗の力 Portrait
=========================================================


本プロジェクトはサムスン社製のスマートテレビ向けデモアプリが含まれます。デジタルサイネージの技術はテレビ画面に広告を表示するために広く用いられます。このサンプルアプリを使ってリアルタイムでスマートテレビに映すコンテンツをAndroid端末から操作して、切り替えることができます。


あなたの作業
----------------

1. HTTPサーバーとWeb Socketのポート

  HTTPサーバーとWeb Socketのポートがindex.htmlファイルの中に指定されています。
  このポートはあなたの環境によって自由に変更することができます。

2. 外観の変更

  このアプリは2つのカテゴリーに別けられます:
  
  - Server side: Android端末上で動くアプリケーション
  - Client side: テレビのスクリーン上で表示されているWebページ
  

  サーバーサイドのページはクライアント側のディレクトリ以外の全てのHTMLファイルを保持しています。index.htmlはページのメインの機能だけではなく、アプリ内の全てのHTMLを保持しています。全てのフレームワークとCSSファイルがここにロードされます。一方で、ネイティブコンポーネントを定義するindex.uiで画面方向を縦に指定しています。index.uiはindex.htmlのネイティブコンポーネントを定義しています。ネイティブコンポーネントについての詳細はこちらの URL: <http://docs.monaca.mobi/reference/native_ui/> をご覧ください。

  サーバーサイドのページはlangディレクトリ中に言語ファイルを含んでいます。このファイルのフォーマットは xxx-ja.json と xxx-cn.jsonです。このアプリのデフォルトの言語は英語ですが端末の言語によって自動的に切り替わります。

  テンプレートファイルはtemplateディレクトリに格納されています。このディレクトリ中のファイルを変更することによって、アプリのコンテンツを変更できます。

  サーバーサイドのページは次のプラグインおよびフレームワークを含んでいます。
  
  ◎ Monaca HTTP Serverプラグイン
  ◎ Monaca WebSocket Serverプラグイン
  ◎ PhoneGapプラグン
  ◎ Backbone.js
  ◎ Marionette.js
  ◎ Underscore.js
  ◎ iScroll.js
  ◎ Fastclick.js
  ◎ Modernizr.js
  ◎ Pageslider.js
  ◎ jQuery Localizationプラグイン
  ◎ TAFFY
  

  Monaca IDEのプラグイン設定からプラグインを追加ないし、削除することができます。このアプリケーションの動作に最小限必要なプラグインは jQuery, Monaca Server, monaca.js, monaca.viewpoer.js PhoneGap (Cordova) です。これらのプラグインはplugin-loader.jsの中で読み込まれます。
  
  クライアントサイドのページはJSONのデータベースを保持しており、データはクライアント側のディレクトリに保存されます。
  cssディレクトリ中のcssファイルもしくはtemplateディレクトリ中のテンプレートファイルを変更することによってアプリケーションのコンテンツを変更することができます。

3. 動作の変更

  メインのJavaScriptのプログラムはjsフォルダ中のcontroller.js中に定義されています。
  このソースコードは好きなように変更することができます。
 
4. デバッグ

  アプリの挙動を確認するためにはMonacaデバッガーを用いる必要があります。このアプリはAndroid端末を必要とする機能を含んでいるために、プレビュー上では正確に挙動を確認することはできません。
 
5. ビルドおよび配布

  このアプリはビルドしてGoogle Playで配布することができます。ビルドおよびマニュアルについての詳細はマニュアルをご覧ください。<http://docs.monaca.mobi/manual/build_index/>
