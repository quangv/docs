App.module('Home.Views', function(Views, App, Backbone, Marionette, $, _) {

	Views.HomeItemView = Marionette.ItemView.extend({
	    template: "template/home_item.tpl",
        
        clientConnected: function(data){
            var self = this;
            socketServer.getClients(function(clients) {
                self.model.set('client_count', clients.length);
                self.render();
                self.setLocale();
            }, function(error) {
                console.log(error);
            });
        },
        
        clientDisconnected: function(data){
            var self = this;
            socketServer.getClients(function(clients) {
                self.model.set('client_count', clients.length);
                self.render();
                self.setLocale();
            }, function(error) {
                console.log(error);
            });
        },

	    events: {
	        'click #photo': 'onClickPhoto',
            'click #client': 'onClickClient',
            'click #preview': 'onClickPreview',
	        'click #config': 'onClickConfig'
	    },

	    onClickPhoto: function(){
	        this.trigger('itemview:photo:click');
	    },
        
        onClickClient: function(){
            this.trigger('itemview:client:click');
        },

	    onClickPreview: function(){
            this.trigger('itemview:preview:click');
	    },
        
        onClickConfig: function(){
	        this.trigger('itemview:config:click');
	    },
        
        setLocale: function(){
        	navigator.globalization.getLocaleName(
                function (locale) {
                    if(locale.value == 'ja_JP') {
                        $("[data-localize]").localize("home", { language: "ja", pathPrefix: "lang" });                        
                    }
                    if(locale.value == 'zh_CN') {
                        $("[data-localize]").localize("home", { language: "cn", pathPrefix: "lang" });                        
                    }
                },
                function () {console.log('Error getting locale\n');}
            );
	    },
        
        onSetLocale: function() {
            this.setLocale();
        },
        
        onShow: function(){
            this.setLocale();
            this.listenTo(App, "client:connected", this.clientConnected); 
            this.listenTo(App, "client:disconnected", this.clientDisconnected);
        }
	    
	});

});