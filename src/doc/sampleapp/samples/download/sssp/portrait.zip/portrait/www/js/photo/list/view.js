App.module('Photo.List.Views', function(Views, App, Backbone, Marionette, $, _) {

	Views.NoItemView = Marionette.ItemView.extend({
        template: "template/no_item.tpl"   
    });
    
    Views.PhotoItemView = Marionette.ItemView.extend({
	    template: "template/photo_item.tpl",
	    tagName: "li",
	    className: "topcoat-list__item",
        
        initialize: function() {
            var self = this;
            Handlebars.registerHelper("getFileUrl", function(value) {
                var fileName = self.model.get("filename");
                return serverRootDir + "data/photo/" + fileName;
            });
            Handlebars.registerHelper("getOnOff", function(value) {
                var enable = self.model.get("enable");
                if(enable == 1) return "Enable";
                else return "Disable";
            });
            Handlebars.registerHelper("getRotate", function(value) {
                var orientation = self.model.get("orientation");
                if(orientation == 6) return "width: 180% !important; background-size: 100% !important; margin-left: -40%; -webkit-transform: rotate(90deg);";
                if(orientation == 8) return "width: 180% !important; background-size: 100% !important; margin-left: -40%; -webkit-transform: rotate(-90deg);";
            });
        },
        
        onShow: function() {
            $("li").attr("draggable", "true");
            $("li").attr("style", "cursor: move;");
        },

	    events: {
	        'click': 'onClick'
	    },

	    onClick: function(){
	        this.trigger('photo:click', this.model);
	    }
	    
	});

	Views.PhotoCompositeView = Backbone.Marionette.CompositeView.extend({
		itemView: Views.PhotoItemView,
		itemViewContainer: "#mixList",
		template: "template/mix_list.tpl",
        
        emptyView: Views.NoItemView,

		events: {
			'click #galleryBtn': 'onClickGalleryBtn',
			'click #cameraBtn': 'onClickCameraBtn'
		},

		onClickGalleryBtn: function(){
			console.log('onClickGalleryBtn');
			this.trigger('gallery:click');
		},

		onClickCameraBtn: function(){
			console.log('onClickCameraBtn');
			this.trigger('camera:click');
		},
        
        onShow: function(){
            navigator.globalization.getLocaleName(
                function (locale) {
                    if(locale.value == 'ja_JP') {
                        $("[data-localize]").localize("photo", { language: "ja", pathPrefix: "lang" });                        
                    }
                    if(locale.value == 'zh_CN') {
                        $("[data-localize]").localize("photo", { language: "cn", pathPrefix: "lang" });                        
                    }
                },
                function () {console.log('Error getting locale\n');}
            );
        }
	});

});