App.module('Client.Detail.Views', function(Views, App, Backbone, Marionette, $, _) {

    Views.ClientDetailView = Marionette.ItemView.extend({
        template: "template/client_detail.tpl",
        
        initialize: function(){
            this.listenTo(App, "get:tvdetail", this.tvDetailReceived);  
        },
        
        tvDetailReceived: function(data){
            var detailModel = new Backbone.Model(data);
            this.model = detailModel;
            this.render();
        },

        setLocale: function() {
            navigator.globalization.getLocaleName(
                function (locale) {
                    // if(locale.value == 'ja_JP') {
                    //     $("[data-localize]").localize("client-detail", { language: "ja", pathPrefix: "lang" });                        
                    // }
                    // if(locale.value == 'zh_CN') {
                    //     $("[data-localize]").localize("client-detail", { language: "cn", pathPrefix: "lang" });                        
                    // }
                },
                function () {console.log('Error getting locale\n');}
            );
        },
        
        onShow: function(){
            this.setLocale();
        }
    });

});