App.module('SSSP', function(SSSP, App, Backbone, Marionette, $, _) {
	var slidingMenu = new App.SlidingMenu.Views.SlidingMenuView();
    var navigationController;

    function createNavigationController(){
        navigationController = new App.Navigation.Views.NavigationController();
        navigationController.on('left-navigation-item:clicked', function() {
    		slidingMenu.toggleMenu();
    	});
        
        navigationController.on('right-navigation-item:clicked', function() {
            console.log('right-navigation-item:clicked clicked');
            var addBtn = document.getElementById('addBtn');
            if(addBtn) {
                if(addBtn.style.display == 'block') {
                    addBtn.style.display = 'none';
                    navigationController.setRightButtonIcon('plus');
                } else {
                    addBtn.style.display = 'block';
                    navigationController.setRightButtonIcon('cancel');
                }
            }
        });
    }
    
    var db = TAFFY();
	var countPhoto, getLastModified, getSlideTime, getSocketServerIp, getSocketServerPort;
    var loading, wait, delete_message, update_message, add_message, update_client;
    var timer;

	SSSP.Controller = {
		showInitialScence: function(animation) {
			var self = this;
			window.db = db;
            
            App.screenRegion.show(slidingMenu, animation);
            
			var menuView = new App.Menu.Views.MenuView();
			slidingMenu.behindRegion.show(menuView);
            createNavigationController();
        	slidingMenu.aboveRegion.show(navigationController);
			navigationController.delegateEvents();
            
            self.showHomeView();                
            
            menuView.on('home:click', function() {
				self.showHomeView();
				slidingMenu.closeMenu();
			});
			menuView.on('photo:click', function() {
				self.showPhotoList();
				slidingMenu.closeMenu();
			});
            menuView.on('client:click', function(){
                self.showClientList();
                slidingMenu.closeMenu();
            });
            menuView.on('preview:click', function() {
    			self.showPreview();
				slidingMenu.closeMenu();
			});
			menuView.on('config:click', function() {
				self.showConfigList();
				slidingMenu.closeMenu();
			});
            menuView.on('about:click', function() {
    			self.showAboutView();
				slidingMenu.closeMenu();
			});
            
		},
        
        loadTranslation: function() {
            navigator.globalization.getLocaleName(
                function (locale) {
                    console.log('locale: ' + locale.value + '\n');
                    if(locale.value == 'ja_JP') {
                        loading = "";
                        wait = "お待ちください...";
                        delete_message = "削除しました。";
                        update_message = "更新しました。";
                        add_message = "追加しました。";
                        update_client = "クライアントを更新中...";
                    }
                    else if(locale.value == 'zh_CN') {
                        loading = "";
                        wait = "请稍后...";
                        delete_message = "删除成功。";
                        update_message = "更新成功。";
                        add_message = "添加成功。";
                        update_client = "正在更新客户端...";
                    }
                    else {
                        loading = "";
                        wait = "Please wait...";
                        delete_message = "Successfully deleted.";
                        update_message = "Successfully updated.";
                        add_message = "Successfully added.";
                        update_client = "Updating client...";
                    }
                },
                function () {console.log('Error getting locale\n');}
            );
        },
        
        updateClient: function(data) {
            socketServer.getClients(function(clients) {
                if(clients.length > 0) {
                    navigator.notification.activityStart(loading,update_client);
                    setTimeout(function(){
                        navigator.notification.activityStop();
                    }, 1500);
                }
                _.each(clients, function(client){
                    socketServer.send(client, "data:changed");
                });
            }, function(error) {
                console.log(error);
            });
        },
        
        onBackKey: function() {
            console.log("I've caught a back key");
            this.showInitialScence("left");
            document.removeEventListener("backbutton", this.backKeyBindding, false);
        },
        
        showPreview: function() {
            var preview = new App.Config.List.Views.Preview({});
            preview.navigationBarItem = {
                title: "Preview"
            };
            this.backKeyBindding = _.bind(this.onBackKey, this);
            document.addEventListener("backbutton", this.backKeyBindding, false);
            App.screenRegion.show(preview, "right");
        },
        
        showStartScreen: function() {
            var self = this;
            var startItemView = new App.Start.Views.StartItemView({});
            startItemView.on('start:click', function() {
                self.showInitialScence();
            });
            App.screenRegion.show(startItemView, "right");
        },
            
        getClientList: function() {
            var clientList;
            socketServer.getClients(function(clients) {
                clientList = _.map(clients, function(client){
                    var data = {
                        "clientId": client
                    }
                    return data;
                });
            }, function(error) {
                console.log(error);
            });
            return clientList;
        },
        
        showClientList: function() {
            var self = this;
            navigationController.setRightButtonIcon('');
            var clientList = self.getClientList();
            var clientCollection = new Backbone.Collection(clientList);
            var clientCompositeView = new App.Client.Views.ClientCompositeView({
                collection: clientCollection
            });
            clientCompositeView.navigationBarItem = {
                title: "Client"
            };
            clientCompositeView.on('itemview:client:reload', function(itemView, client) {
                navigator.notification.activityStart(loading,wait);
                socketServer.send(client.attributes.clientId, "reload");
                setTimeout(function() {
                    navigator.notification.activityStop();
                }, 5000);
            });
            clientCompositeView.on('itemview:client:click', function(itemView, client) {
                navigator.notification.activityStart(loading,wait);
                setTimeout(function() {
                    socketServer.send(client.attributes.clientId, "tvdetail");
                    self.showClientDetail(client.attributes.clientId);
                    navigator.notification.activityStop();
                }, 500);
            });
            navigationController.resetRootView(clientCompositeView);
        },
        
        showClientDetail: function(clientId) {
            var self = this;
            var clientDetailView = new App.Client.Detail.Views.ClientDetailView({});
            clientDetailView.navigationBarItem = {
                title: clientId
            };
            navigationController.showChildView(clientDetailView, "right");
        },

		getConfigItem: function() {
            var self = this;
            App.request('photo:entities').done(function(photos) {
                self.countPhoto = photos.length;
            });
            App.request('config:entities').done(function(configs) {
            	self.getLastModified = configs.attributes.last_modified;
                self.getSlideTime = configs.attributes.slide_time;
                self.getSocketServerIp = configs.attributes.socket_server_ip;
                self.getSocketServerPort = configs.attributes.socket_server_port;
            });
        },
        
        showHomeView: function() {
			console.log('[showHomeView] init');
			var self = this;
			navigationController.setLeftButtonIcon('menu-stack');
			navigationController.setRightButtonIcon('');
    		
            var configs = new Backbone.Model();
            var homeItemView = new App.Home.Views.HomeItemView({
                model: configs
            });
            homeItemView.navigationBarItem = {
                title: "Home"
            };
            configs.set('status', '');
            if(serverUrl.ip) {
                configs.set('serverStatus', 'server_start');
                configs.set('getDescription', 'Server has been successfully started.');
            } else {
                configs.set('serverStatus', 'server_error');
                configs.set('getDescription', 'Loading server failed. Please check your network connection.');
			}
            socketServer.getClients(function(clients) {
                configs.set('client_count', clients.length);
            }, function(error) {
                console.log(error);
            });
            homeItemView.on('itemview:photo:click', function(childView) {
                self.showPhotoList();
            });
            homeItemView.on('itemview:client:click', function(childView) {
                self.showClientList();
            });
            homeItemView.on('itemview:preview:click', function(childView) {
                self.showPreview();
            });
            homeItemView.on('itemview:config:click', function(childView) {
                self.showConfigList();
            });
            App.request('photo:entities').done(function(photos) {
                self.countPhoto = photos.length;
                configs.set('photo_count', photos.length);
                App.request('config:entities').done(function(configs) {
                    self.getLastModified = configs.attributes.last_modified;
                    self.getSlideTime = configs.attributes.slide_time;
                    self.getSocketServerIp = configs.attributes.socket_server_ip;
                    self.getSocketServerPort = configs.attributes.socket_server_port;
                    navigationController.resetRootView(homeItemView);
                });
            });
		},

		showPhotoList: function() {
			console.log('[showPhotoList] init');
			var self = this;
            App.request('photo:entities').done(function(photos) {
                window.photos = photos;
                self.db = TAFFY(JSON.stringify(photos));
                window.db = self.db;
                var photoCompositeView = new App.Photo.List.Views.PhotoCompositeView({
                    collection: photos
                });
                photoCompositeView.navigationBarItem = {
                    title: "Picture",
                    rightButtonIcon: "plus"
                };
                photoCompositeView.on('itemview:photo:click', function(childView, photo) {
                    console.log('Photo Item clicked');
                    self.showPhotoDetail(photo);
                });
                photoCompositeView.on('gallery:click', function(childView) {
                    console.log('Gallery Button clicked');
                    self.getPhotoGallery();
                });
                photoCompositeView.on('camera:click', function(childView) {
                    console.log('Camera Button clicked');
                    self.getPhotoCamera();
                });
            	navigationController.resetRootView(photoCompositeView);
            });
		},

		showPhotoDetail: function(photo) {
            var self = this;
            window.photo = photo;
            navigationController.setRightButtonIcon('');
        	var photoDetailView = new App.Photo.Detail.Views.PhotoDetailView({
                model: photo
            });
            photoDetailView.navigationBarItem = {
                title: "Update"
            };
            self.getConfigItem();
            photoDetailView.on('delete-btn:clicked', function(data) {
                console.log('Delete Button clicked. id: ' + data.id);
                var updateDb = self.db({id:{"!is":parseInt(data.id)}}).stringify();
                console.log('updateDb: '+updateDb);
                if(data.fileName) self.deleteFile(serverRootDir + "data/photo/" + data.fileName);
                var date="";
                var d = new Date();
                date="" + d.getFullYear() + "/" + ("0"+(d.getMonth()+1)).substr(-2) + "/" + ("0"+d.getDate()).substr(-2) + " " + d.getHours() + ":" + ("0"+d.getMinutes()).substr(-2) + ":" + ("0"+d.getSeconds()).substr(-2);
            
                //save new photo file
                self.saveData(updateDb, "data/photo.json", delete_message);
                var newData = {
                    "last_modified": date,
                    "slide_time": self.getSlideTime,
                    "socket_server_ip": self.getSocketServerIp,
                    "socket_server_port": self.getSocketServerPort
                    
                }
                self.saveData(newData,"data/config.json","");
                self.showPhotoList();
            });
            photoDetailView.on('update-btn:clicked', function(data) {
                console.log('id: ' + data.id + ' title: '+data.title);
                //extract new row
                var row = TAFFY(self.db({id:{is:parseInt(data.id)}}).stringify());
                //console.log('row: '+row);
                //remove the extracted row
                var updateDb = TAFFY(self.db({id:{"!is":parseInt(data.id)}}).stringify());
                console.log('updateDb: '+updateDb().stringify());
                //update the new row data
                row().update({"id":data.id, "title":data.title, "enable":data.enable});
                console.log('new row: '+row().stringify());
                //insert new row
                updateDb.insert({
                    "id": parseInt(row().select("id")),
                    "filename": String(row().select("filename")),
                    "title": String(row().select("title")),
                    "date": String(row().select("date")),
                    "enable": parseInt(row().select("enable")),
                    "orientation": parseInt(row().select("orientation"))
                });
                console.log('new updateDb: '+updateDb().stringify());
                var date="";
                var d = new Date();
                date="" + d.getFullYear() + "/" + ("0"+(d.getMonth()+1)).substr(-2) + "/" + ("0"+d.getDate()).substr(-2) + " " + d.getHours() + ":" + ("0"+d.getMinutes()).substr(-2) + ":" + ("0"+d.getSeconds()).substr(-2);
                
                //save new database file by id order
                self.saveData(updateDb().order("id").stringify(), "data/photo.json", update_message);
                var newData = {
                    "last_modified": date,
                    "slide_time": self.getSlideTime,
                    "socket_server_ip": self.getSocketServerIp,
                    "socket_server_port": self.getSocketServerPort
                }
                self.saveData(newData,"data/config.json","");
                self.showPhotoList();
            });
            navigationController.showChildView(photoDetailView, "right");
        },

		showConfigList: function() {
			console.log('[showConfigList] init');
			var self = this;
            navigationController.setRightButtonIcon('');
            self.getConfigItem();
            App.request('config:entities').done(function(configs) {
                window.configs = configs;
                self.db = TAFFY(JSON.stringify(configs));
	            window.db = self.db;
                var configItemView = new App.Config.List.Views.ConfigItemView({
                    model: configs
                });
                configs.set('photo_count', self.countPhoto);
                if(serverUrl)   configs.set('serverUrl', 'http://' + serverUrl.ip + ':' + serverUrl.port);
                configItemView.navigationBarItem = {
                    title: "Setting"
                };
                configItemView.on('slidetime:changed', function(data){
                    //clear previous timer
                    clearTimeout(self.timer);
                    var date="";
                    var d = new Date();
                    date="" + d.getFullYear() + "/" + ("0"+(d.getMonth()+1)).substr(-2) + "/" + ("0"+d.getDate()).substr(-2) + " " + d.getHours() + ":" + ("0"+d.getMinutes()).substr(-2) + ":" + ("0"+d.getSeconds()).substr(-2);
                    var newData = {
                        "last_modified": date,
                        "slide_time": data.slide_time,
                        "socket_server_ip": self.getSocketServerIp,
                        "socket_server_port": self.getSocketServerPort
                    }
                    self.timer = setTimeout(function(){
                        //update database only after 2 seconds
                        self.saveData(newData,"data/config.json","silent");
                    }, 2000);
                });
                navigationController.resetRootView(configItemView);
            });
		},
        
        showAboutView: function() {
            var self = this;
            navigationController.setRightButtonIcon('');
            var aboutItemView = new App.About.Views.AboutItemView({});
            aboutItemView.navigationBarItem = {
                title: "About"
            };
            aboutItemView.on('help:click', function() {
                self.showHelpView();
            });
            aboutItemView.on('usage:click', function() {
                self.showUsageView();
            });
            navigationController.resetRootView(aboutItemView);
    	},
        
        showHelpView: function() {
            var self = this;
            var helpItemView = new App.About.Help.Views.HelpItemView({});
            helpItemView.navigationBarItem = {
                title: "ヘルプ"
            };
            navigationController.showChildView(helpItemView, "right");
        },
        
        showUsageView: function() {
            var self = this;
            var usageItemView = new App.About.Usage.Views.UsageItemView({});
            usageItemView.navigationBarItem = {
                title: "利用規約"
            };
            navigationController.showChildView(usageItemView, "right");
        },

        addNew: function(args, dataPath){
            var self = this;
            var maxId = parseInt(self.db().max("id"));
            var newId = maxId + 1;
            if (!newId) newId = 1;
            var date="";
            var d = new Date();
            date="" + d.getFullYear() + "/" + ("0"+(d.getMonth()+1)).substr(-2) + "/" + ("0"+d.getDate()).substr(-2) + " " + d.getHours() + ":" + ("0"+d.getMinutes()).substr(-2) + ":" + ("0"+d.getSeconds()).substr(-2);
            var enable = 1;
            self.getConfigItem();
            var menuItemData = {
                "id": newId,
                "filename": args.filename,
                "title": "",
                "date": date,
                "enable": enable,
                "orientation": args.orientation
            };
            self.db.insert(menuItemData);
            //write to json file
            self.saveData(self.db().stringify(), dataPath, add_message);
            var newData = {
                "last_modified": date,
                "slide_time": self.getSlideTime,
                "socket_server_ip": self.getSocketServerIp,
                "socket_server_port": self.getSocketServerPort
            }
            window.newData = newData;
            self.saveData(newData,"data/config.json","");
        },
        
        saveData: function(data, dataFile, message){
            var self = this;
            console.log('file: ' + dataFile + ' save data: ' + JSON.stringify(data));
            var gotFS = function(fileSystem){
                fileSystem.root.getFile(serverRootDir + dataFile, {create: true, exclusive: false},
                function(fileEntry){
                    fileEntry.createWriter(gotFileWriter, fail);
                },
                function(error){
                    alert('error:' + JSON.stringify(error));
                });
            };
            var gotFileWriter = function(writer){
                writer.write(data);
                if(message == "silent") {
                    self.updateClient();
                }
                if(message != "" && message != "silent") {
                    alert(message);
                    self.updateClient();
                }
            };
            function fail(error){
                console.log('error: '+JSON.stringify(error));
            }
            window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFS, fail);
        },
        
        deleteFile: function(file){
            console.log('delete file: ' + file);
            var gotFS = function(fileSystem){
                fileSystem.root.getFile(file, null, gotFileEntry, fail);
            }
            function gotFileEntry(fileEntry) {
                fileEntry.remove();
            }
            function fail(error){
                console.log('error: '+JSON.stringify(error));
            }
            window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFS, fail);
        },
        
        getOrientation: function(imgDataURL){
            var byteString = atob(imgDataURL.split(',')[1]);
            var orientaion = byteStringToOrientation(byteString);
            return orientaion;
    
            function byteStringToOrientation(img){
                var head = 0;
                var orientation;
                while (1){
                    if (img.charCodeAt(head) == 255 & img.charCodeAt(head + 1) == 218) {break;}
                    if (img.charCodeAt(head) == 255 & img.charCodeAt(head + 1) == 216) {
                        head += 2;
                    }
                    else {
                        var length = img.charCodeAt(head + 2) * 256 + img.charCodeAt(head + 3);
                        var endPoint = head + length + 2;
                        if (img.charCodeAt(head) == 255 & img.charCodeAt(head + 1) == 225) {
                            var segment = img.slice(head, endPoint);
                            var bigEndian = segment.charCodeAt(10) == 77;
                            if (bigEndian) {
                                var count = segment.charCodeAt(18) * 256 + segment.charCodeAt(19);
                            } else {
                                var count = segment.charCodeAt(18) + segment.charCodeAt(19) * 256;
                            }
                            for (i=0;i<count;i++){
                                var field = segment.slice(20 + 12 * i, 32 + 12 * i);
                                if ((bigEndian && field.charCodeAt(1) == 18) || (!bigEndian && field.charCodeAt(0) == 18)) {
                                    orientation = bigEndian ? field.charCodeAt(9) : field.charCodeAt(8);
                                }
                            }
                            break;
                        }
                        head = endPoint;
                    }
                    if (head > img.length){break;}
                }
                return orientation;
            }
        },

        getPhotoGallery: function(){
            console.log('[getPhotoGallery]');
            var self = this;
            var filename, loc;
            navigator.camera.getPicture(function(imageURI){
                //alert(imageURI);
                var gotFileEntry = function(fileEntry) { 
                    var gotFileSystem = function(fileSystem){
                        console.log('imageURI: '+imageURI);
                        console.log('full path: '+ fileEntry.fullPath);
                        
                        fr = new FileReader;
                        var orientation;
                        var width, height;
                        fr.onloadend = function(evt) {
                            orientation = self.getOrientation(evt.target.result);
                        };
                        fr.readAsDataURL(fileEntry);
                        
                        filename = imageURI.substring(imageURI.lastIndexOf('/')+1);
                        console.log('filename: ' + filename);
                        loc = serverRootDir + "data/photo/";
                        console.log('location: '+loc);
                        var parentDirectory = new DirectoryEntry('photo', loc);
                        //check if folder exist, if not create to prevent data empty and bootloader wont copy file
                        parentDirectory.getDirectory(loc, {create: true, exclusive: false}, function(parent){
                            console.log("Parent Name: " + parent.name);
                        }, function(error){
                            alert("Unable to create new directory: " + error.code);
                        });
                        fileEntry.copyTo(parentDirectory, filename, 
                        function(something){
                            //success move file, update Database
                            self.addNew({"filename": filename, "orientation": orientation}, "data/photo.json");
                            self.showPhotoList();
                        }, 
                        function(error){
                            alert('move failed. error:' + JSON.stringify(error));
                        });
                   };
                    // get file system to copy or move image file to 
                    window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFileSystem, function(error){
                        alert("error: " + error.code); 
                    }); 
                }; 
                //resolve file system for image  
                window.resolveLocalFileSystemURI(imageURI, gotFileEntry, function(error){
                    alert("error: " + error.code); 
                });
            }, function(message) {
                alert(message);
            }, {
        		quality: 100,
                sourceType : Camera.PictureSourceType.PHOTOLIBRARY
        	});
        },

        getPhotoCamera: function(){
            console.log('[getPhotoCamera]');
            var self = this;
            var filename, loc;
            navigator.camera.getPicture(function(imageURI){
                var gotFileEntry = function(fileEntry) { 
                    var gotFileSystem = function(fileSystem){
                        console.log('imageURI: '+imageURI);
                        filename = imageURI.substring(imageURI.lastIndexOf('/')+1);
                        loc = serverRootDir + "data/photo/";
                        console.log('location: '+loc);
                        var parentDirectory = new DirectoryEntry('photo', loc);
                        //check if folder exist, if not create to prevent data empty and bootloader wont copy file
                        parentDirectory.getDirectory(loc, {create: true, exclusive: false}, function(parent){
                            console.log("Parent Name: " + parent.name);
                        }, function(error){
                            alert("Unable to create new directory: " + error.code);
                        });
                        fileEntry.copyTo(parentDirectory, filename, 
                        function(something){
                            //remove taken file after copy
                            fileEntry.remove();
                            //success move file, update Database
                            self.addNew({"filename": filename, "orientation": 1}, "data/photo.json");
                            self.showPhotoList();
                        }, 
                        function(error){
                            alert('move failed. error:' + JSON.stringify(error));
                        });
                   };
                    // get file system to copy or move image file to 
                    window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFileSystem, function(error){
                        alert("error: " + error.code); 
                    }); 
                }; 
                //resolve file system for image  
                window.resolveLocalFileSystemURI(imageURI, gotFileEntry, function(error){
                    alert("error: " + error.code); 
                });
            }, function(message) {
                alert(message);
        	}, {
        		quality: 100,
                allowEdit : true,
                correctOrientation: true,
        		destinationType : Camera.DestinationType.FILE_URI
        	});
        }

	}

	App.addInitializer(function() {
	    App.on('websocketserver:started', function(response) {
            App.request('config:entities').done(function(configs) {
                self.getLastModified = configs.attributes.last_modified;
                App.SSSP.Controller.loadTranslation();
                navigator.notification.activityStart(loading,wait);
                var configData = {
                    "last_modified": configs.attributes.last_modified,
                    "slide_time": configs.attributes.slide_time,
                    "socket_server_ip": response.ip,
                    "socket_server_port": response.port
                }
                App.SSSP.Controller.saveData(configData,'data/config.json','');
                setTimeout(function(){
                    App.SSSP.Controller.showInitialScence();
                    navigator.notification.activityStop();
                }, 500);
            });
        });
	});
    
});