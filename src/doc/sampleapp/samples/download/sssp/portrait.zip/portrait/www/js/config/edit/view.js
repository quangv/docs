App.module('Config.Edit.Views', function(Views, App, Backbone, Marionette, $, _) {

    Views.ConfigEditView = Marionette.ItemView.extend({
		template: "template/config_edit_item.tpl",
        
	    events: {
            'click #updateBtn': 'updateBtn'
	    },

	    updateBtn: function(){
	        console.log('onClick updateBtn');
	        var slide_time = this.$('#slide_time').val();
            var data = {
                slide_time: slide_time
            }
            this.trigger('update-btn:clicked', data);
	    }
	});

});