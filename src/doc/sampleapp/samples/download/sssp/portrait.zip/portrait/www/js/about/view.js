App.module('About.Views', function(Views, App, Backbone, Marionette, $, _) {

    Views.AboutItemView = Marionette.ItemView.extend({
	    template: "template/about.tpl",

	    events: {
	        'click #help': 'onClickHelp',
            'click #usage': 'onClickUsage'
	    },

	    onClickHelp: function(){
	        this.trigger('help:click');
	    },
        
        onClickUsage: function(){
            this.trigger('usage:click');
	    },
        
        onShow: function(){
        	navigator.globalization.getLocaleName(
                function (locale) {
                    if(locale.value == 'ja_JP') {
                        $("[data-localize]").localize("about", { language: "ja", pathPrefix: "lang" });                        
                    }
                    if(locale.value == 'zh_CN') {
                        $("[data-localize]").localize("about", { language: "cn", pathPrefix: "lang" });                        
                    }
                },
                function () {console.log('Error getting locale\n');}
            );
	    }
	    
	});

});