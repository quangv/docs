App.module('List', function(List, App, Backbone, Marionette, $, _) {
    
    var containerRegion = new App.ScreenLayout.Views.SlidingLayoutRegion({
        el: "#slideshow"
    });

    App.addRegions({
        containerRegion: containerRegion
    });
    
    var timer;
    var slide_time;
    var connection;
    
    List.Controller = {
        showInitialScence: function(init) {
            var self = this;
            if(!self.slide_time) self.slide_time = 5;    //set default to 5
            self.showSpinner();
            setTimeout(function(){
                App.request('config:entities').done(function(config) {
                    window.config = config;
                    self.slide_time = config.attributes.slide_time;
                    if(init == 1) self.createWebSocketConnection(config);
                    self.showPhoto();
                });
            }, 500);
        },
        
        createWebSocketConnection: function(config) {
            var self = this;
            self.connection = new WebSocket("ws://"+config.attributes.socket_server_ip+":"+config.attributes.socket_server_port);
            self.connection.onopen = function(e) {
                self.showPhoto();
            }
            self.connection.onmessage = function(message) {
                console.log(message);
                if(message.data === "up") {
                    App.TV.Remote.runVolumeUp();
                }
                if(message.data === "down") {
                    App.TV.Remote.runVolumeDown();
                }
                if(message.data === "data:changed") {
                    self.showInitialScence(0);
                }
                if(message.data === "reload") {
                    if(self.connection.readyState === 1) {
                        self.connection.close();
                    }
                    window.location.reload();
                }
                if(message.data === "tvdetail") {
                    var detail = App.TV.Remote.getTvDetail();
                    var tvDetail = {
                        "con": detail.con,
                        "duid": detail.duid,
                        "mac": detail.mac,
                        "firmware": detail.firmware,
                        "volume": detail.volume,
                        "model": detail.model
                    }
                    var message = {
                        "tvdetail": tvDetail
                    }
                    self.connection.send(JSON.stringify(message));
                }
            }
            self.connection.onclose = function(e) {
                setTimeout(function(){
                    self.createWebSocketConnection(config);
                }, 5000);  
            }
        },
        
        showPhoto: function() {
            var self = this;
            App.request('photo:entities').done(function(photos) {
                window.photos = photos;
                var ua = navigator.userAgent.toLowerCase();
                var isSmartTV = ua.indexOf("smarttv") > -1;
                if(isSmartTV) {
                    $("#slideshow").css("-webkit-transform", "rotate(-90deg)");
                    self.rotatePage();
                    
                } else {
                    $("#slideshow").css("width", "100%");
                    $("#slideshow").css("height", "100%");
                    $("#slideshow").css("top", "0");
                    $("#slideshow").css("position", "absolute");
                }
                self.slideshow(photos);
            });
        },
        
        showSpinner: function() {
            var opts = {
                lines: 13, // The number of lines to draw
                length: 20, // The length of each line
                width: 10, // The line thickness
                radius: 30, // The radius of the inner circle
                corners: 1, // Corner roundness (0..1)
                rotate: 0, // The rotation offset
                direction: 1, // 1: clockwise, -1: counterclockwise
                color: '#000', // #rgb or #rrggbb
                speed: 1, // Rounds per second
                trail: 60, // Afterglow percentage
                shadow: false, // Whether to render a shadow
                hwaccel: false, // Whether to use hardware acceleration
                className: 'spinner', // The CSS class to assign to the spinner
                zIndex: 2e9, // The z-index (defaults to 2000000000)
                top: 'auto', // Top position relative to parent in px
                left: 'auto' // Left position relative to parent in px
            };
            var target = document.getElementById('spinner');
            target.style.display = "block";
            var spinner = new Spinner(opts).spin(target);
            setTimeout(function(){
                spinner.stop();
                target.style.display = "none";
            }, 1500);
        },
        
        slideshow: function(photos) {
            var self = this;
            var photo;
            var photoView;
            var photoViews = [];
            clearInterval(self.timer);
            for(var i=0; i< photos.length; i++){
                photo = photos.models[i];
                photoView = new App.Photo.List.Views.PhotoItemView({
                    model: photo
                });
                if(photoView.model.attributes.enable == 1)  photoViews.push(photoView);
                window.photoViews = photoViews;
            }
            if(photoViews.length > 0) {
                function calculateNextPhotoIndex(){
                    currentIndex++;
                    if(currentIndex >= photos.length){
                        currentIndex = 0;
                    }                        
                }
                var currentIndex = 0;
                if(!self.slide_time) self.slide_time = 5;       //set default slide_time to 5
                var slideInterval = self.slide_time * 1000;
                console.log('slide_time: ' + slideInterval);
                App.containerRegion.show(photoViews[currentIndex], "fade");
                self.timer = setInterval(function(){
                    calculateNextPhotoIndex();
                    App.containerRegion.show(photoViews[currentIndex], "fade");
                }, slideInterval);                
            } else {
                var noItemView = new App.Photo.List.Views.NoItemView({});
                App.containerRegion.show(noItemView, "fade");
            }
        },
        
        rotatePage: function() {
            console.log("window.width: " + $(window).width() + " window.height: " + $(window).height());
            var slideshow = document.getElementById("slideshow");
            var containerWidth = $(window).width();
            var containerHeight = $(window).height();
            
            slideshow.style.width = containerHeight + "px";
            slideshow.style.height = containerWidth + "px";
            var slideShowTop = ( containerWidth - containerHeight ) / 2;
            slideshow.style.top = -slideShowTop + "px";
            slideshow.style.left = slideShowTop + "px";
        }
    }
    
	App.addInitializer(function() {
		List.Controller.showInitialScence(1);
	});
});