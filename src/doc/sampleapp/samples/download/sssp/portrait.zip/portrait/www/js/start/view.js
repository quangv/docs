App.module('Start.Views', function(Views, App, Backbone, Marionette, $, _) {

    Views.StartItemView = Marionette.ItemView.extend({
	    template: "template/start_screen.tpl",
        tagName: 'div',
        className: 'full',

	    events: {
	        'click #start': 'onClickStart'
	    },

	    onClickStart: function(){
	        this.trigger('start:click');
	    }
	    
	});

});