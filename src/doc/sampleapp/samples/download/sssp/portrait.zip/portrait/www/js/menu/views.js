App.module('Menu.Views', function(Views, App, Backbone, Marionette, $, _) {

	Views.MenuView = Marionette.ItemView.extend({
		template: 'js/menu/menu_template.tmpl',

		events: {
			'click #home': 'onHomeClicked',
			'click #photo': 'onPhotoClicked',
    		'click #client': 'onClickClient',
            'click #preview': 'onPreviewClicked',
			'click #config': 'onConfigClicked',
    		'click #about': 'onAboutClicked'
		},

		onHomeClicked: function() {
			this.trigger('home:click');
		},

		onPhotoClicked: function() {
			this.trigger('photo:click');
		},
        
        onClickClient: function(){
            this.trigger('client:click');
        },
        
        onPreviewClicked: function() {
    		this.trigger('preview:click');
		},

		onConfigClicked: function() {
			this.trigger('config:click');
		},

    	onAboutClicked: function() {
			this.trigger('about:click');
		}
        
	});

});