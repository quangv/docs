App.module('Navigation.Regions', function(Regions, App, Backbone, Marionette, $, _) {

	Regions.ContentRegion = Marionette.Region.extend({

		initialize: function(options) {
			this.el = options.el;
		},

		show: function(view, from) {
			this.ensureEl();

			var isViewClosed = view.isClosed || _.isUndefined(view.$el);

			var isDifferentView = view !== this.currentView;

			view.render();

			if (isDifferentView || isViewClosed) {
				this.open(view, from);
			}

			this.currentView = view;

			Marionette.triggerMethod.call(this, "show", view);
			Marionette.triggerMethod.call(view, "show");
		},

		open: function(view, from) {
			console.log('[ContentRegion] open(view) animation ' + from);
			var previousPager = this.$el.find("#pager");

			var to = "";
			if (from) {
				to = from === "left" ? "right" : "left";
			}

			var that = this;
			var previousView = this.currentView;

			// add page to container
			var pager = $('<div id="pager"><div id="scroller"></div></div>');
			this.currentPager = pager;
			var scroller = pager.find('#scroller');
			scroller.append(view.el);

			this.$el.append(pager);

			// position at the right
			pager.attr("class", "page " + from);

			if (!previousView || previousView.isClosed) {
				pager.attr("class", "page center");
				return;
			}

			if (!from) { // no animation
				if (previousView) {
					that.closePreviousView(previousView);
				}
				previousPager.remove();
				return;
			} else {
				previousPager.one('webkitTransitionEnd', function(e) {
					that.closePreviousView(previousView);
					previousPager.remove();
				});
			}


			// Force reflow. More information here: http://www.phpied.com/rendering-repaint-reflowrelayout-restyle/
			this.$el[0].offsetWidth;

			// animate the right page to center
			// and center page to the left
			pager.attr("class", "page transition center");
			previousPager.attr("class", "page transition " + to);
		},

		close: function() {
			// var view = this.currentView;
			// if (!view || view.isClosed){ return; }

			// call 'close' or 'remove', depending on which is found
			// if (view.close) { view.close(); }
			// else if (view.remove) { view.remove(); }

			// Marionette.triggerMethod.call(this, "close");

			// delete this.currentView;
		},

		closePreviousView: function(view) {
			console.log("[ContentRegion] closePreviousView()");
			if (view.close) {
				view.close();
			} else if (view.remove) {
				view.remove();
			}

			Marionette.triggerMethod.call(this, "close");
		},

		onShow: function(view) {
			console.log('[ContentRegion] onShow(view)');

			var self = this;
			setTimeout(function(){
				self.fixScroll();
			}, 500);
		},

		fixScroll: function() {
			if (!Modernizr.overflowtouch) {
				console.log('fixing scroll');
				var wrapper = this.currentPager.get(0);
                this.iScroll = new IScroll(wrapper, {
					momentum: true,
					bounceLock: true,
					bounce: true,
                    onBeforeScrollStart: function (e) {
                        var target = e.target;
                        while (target.nodeType != 1) target = target.parentNode;
                        if (target.tagName != 'SELECT' && target.tagName != 'INPUT' && target.tagName != 'TEXTAREA')
                            e.preventDefault();
                    }
				});
                window.iScroll = this.iScroll;
			}
		}
	});

});