App.module('SlidingMenu.Views', function(Views, App, Backbone, Marionette, $, _) {
	Views.SlidingMenuView = Marionette.Layout.extend({
		template: 'js/framework/sliding_menu/sliding_menu_view_layout.tmpl',
		isOpen: false,
		regions: {
			behindRegion: "#behind-region",
			aboveRegion: "#above-region"
		},

		openMenu: function() {
			var that = this;
			this.aboveRegionElement.one('webkitTransitionEnd', function(e) {
				that.trigger('menu:opened');
			});
			this.aboveRegionElement.attr('class', 'above full-screen open transition');
			this.isOpen = true;
		},

		closeMenu: function() {
			var that = this;
			this.aboveRegionElement.one('webkitTransitionEnd', function(e) {
				that.trigger('menu:closed');
			});
			this.aboveRegionElement.attr('class', 'above full-screen close transition');
			this.isOpen = false;
		},

		toggleMenu: function() {
			if (this.isOpen) {
				this.closeMenu();
			} else {
				this.openMenu();
			}
		},

		onRender: function() {
			this.aboveRegionElement = this.$('#above-region');
		}
	});

});