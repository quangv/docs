App.module('About.Usage.Views', function(Views, App, Backbone, Marionette, $, _) {

    Views.UsageItemView = Marionette.ItemView.extend({
        template: "template/usage.tpl",
        
        onShow: function(){
            navigator.globalization.getLocaleName(
                function (locale) {
                    if(locale.value == 'ja_JP') {
                        $("[data-localize]").localize("usage", { language: "ja", pathPrefix: "lang" });                        
                    }
                },
                function () {console.log('Error getting locale\n');}
            );
        }
    });

});