var App = new Marionette.Application();

// ************************** Override Default Behavior *************************************** //
Backbone.Marionette.TemplateCache.prototype.loadTemplate = function(templateId){
    // load your template here, returning a the data needed for the compileTemplate
    // function. For example, you have a function that creates templates based on the
    // value of templateId
    
    var strUrl = templateId, myTemplate = "";
    console.log('templateUrl: ' + strUrl);
    $.ajax({
        url: strUrl,
        success: function(html) {      
            myTemplate = html;
        },
        error: function(data){
            console.log('error ' + JSON.stringify(data) );
        },
        async:false,
        dataType: "text"        //return only string, not HTML object
    });
    
    // send the template back
    return myTemplate;
}

Backbone.Marionette.TemplateCache.prototype.compileTemplate = function(rawTemplate) {
    // use Handlebars.js to compile the template
    return Handlebars.compile(rawTemplate);
}
