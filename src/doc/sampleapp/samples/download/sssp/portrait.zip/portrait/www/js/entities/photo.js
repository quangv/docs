App.module('Entities', function(Entities, App, Backbone, Marionette, $, _) {
	
	Entities.Photo = Backbone.Model.extend({});

	Entities.PhotoCollection = Backbone.Collection.extend({
		model: Entities.Photo,
		//sort collection by descending order
        comparator: function(left, right){
            var leftItem = parseFloat(left.get('id'));
            var rightItem = parseFloat(right.get('id'));
            if(leftItem < rightItem){       
                return 1;
            }else{       
                return -1;
            }
            return 0;
        }
	});

	var photos;
    
	var initialize = function() {
		var defer = $.Deferred();

        var url = serverRootDir + "data/photo.json";

		getData(url).done(function(data){
			photos = new Entities.PhotoCollection(data);
			defer.resolve(photos);
		});

		return defer.promise();
	};

	var getData = function(url) {
		console.log('url: ' + url);
		var defer = $.Deferred();
		$.ajax({
			url: url,
			'dataType': 'json',
			success: function(data) {
				//console.log('got data from server. ' + JSON.stringify(data));
				defer.resolve(data);
			},
			error: function(data){
				console.log('error ' + JSON.stringify(data));
				defer.resolve(undefined);
			}
		});
		return defer.promise();
	};

	var API = {
		getPhotoEntity: function() {
			return initialize();
		}
	};

	App.reqres.setHandler('photo:entities', function() {
        return API.getPhotoEntity();
	});
});